package com.wahidejaz.mrmistrious;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_PHOTOS = 41;
    private static final int NOTIFICATION_PERMISSION = 42;
    private EditText tokenInput;
    private TextView selectedText;
    private ArrayList<Uri> selectedUris = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 24);
        root.setGravity(Gravity.TOP);
        root.setBackgroundColor(0xFFF4F5F7);

        TextView title = new TextView(this);
        title.setText("MR. MISTRIOUS"); title.setTextSize(25); title.setTextColor(0xFF151923); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("ارسال عکس‌های انتخاب‌شده به تلگرام خودت\n\nبرای شروع، توکن ربات را وارد کن. توکن فقط برای همین نوبت استفاده می‌شود و در برنامه ذخیره نمی‌شود.");
        info.setTextSize(16); info.setTextColor(0xFF343A40); info.setPadding(0, 22, 0, 18);
        root.addView(info);

        tokenInput = new EditText(this);
        tokenInput.setSingleLine(true); tokenInput.setHint("Telegram Bot Token"); tokenInput.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD );
        root.addView(tokenInput, new LinearLayout.LayoutParams(-1, -2));

        Button pick = new Button(this); pick.setText("انتخاب عکس از گالری");
        root.addView(pick, fullWidth());
        pick.setOnClickListener(v -> openPicker());

        selectedText = new TextView(this); selectedText.setText("هنوز عکسی انتخاب نشده است."); selectedText.setTextSize(14); selectedText.setTextColor(0xFF444444); selectedText.setPadding(0, 12, 0, 12);
        root.addView(selectedText);

        Button send = new Button(this); send.setText("شروع ارسال به تلگرام");
        root.addView(send, fullWidth());
        send.setOnClickListener(v -> startSending());

        Button stop = new Button(this); stop.setText("توقف ارسال پس‌زمینه");
        root.addView(stop, fullWidth());
        stop.setOnClickListener(v -> { stopService(new Intent(this, PhotoUploadService.class)); Toast.makeText(this, "درخواست توقف ارسال داده شد.", Toast.LENGTH_SHORT).show(); });

        TextView note = new TextView(this);
        note.setText("نکته: ابتدا در تلگرام وارد ربات @Mistrious_1928_bot شو و Start را بزن. سپس یک پیام به ربات بفرست تا مقصد شناسایی شود. فقط عکس‌هایی که خودت انتخاب می‌کنی ارسال می‌شوند.");
        note.setTextSize(13); note.setTextColor(0xFF555D68); note.setPadding(0, 22, 0, 0);
        root.addView(note);
        setContentView(root);
    }

    private LinearLayout.LayoutParams fullWidth() { return new LinearLayout.LayoutParams(-1, -2); }

    private void openPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_PHOTOS);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_PHOTOS || resultCode != RESULT_OK || data == null) return;
        selectedUris.clear();
        try {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) selectedUris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) selectedUris.add(data.getData());
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            for (Uri uri : selectedUris) {
                try { getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        selectedText.setText("تعداد عکس‌های انتخاب‌شده: " + selectedUris.size());
    }

    private void startSending() {
        String token = tokenInput.getText().toString().trim();
        if (token.isEmpty()) { tokenInput.setError("توکن ربات را وارد کن"); return; }
        if (selectedUris.isEmpty()) { Toast.makeText(this, "اول عکس انتخاب کن.", Toast.LENGTH_SHORT).show(); return; }
        Intent service = new Intent(this, PhotoUploadService.class);
        service.putExtra(PhotoUploadService.EXTRA_TOKEN, token);
        service.putParcelableArrayListExtra(PhotoUploadService.EXTRA_URIS, selectedUris);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        tokenInput.setText("");
        Toast.makeText(this, "ارسال در پس‌زمینه شروع شد.", Toast.LENGTH_LONG).show();
    }
}

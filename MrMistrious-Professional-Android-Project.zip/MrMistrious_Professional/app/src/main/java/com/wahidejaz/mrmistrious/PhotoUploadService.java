package com.wahidejaz.mrmistrious;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.OpenableColumns;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class PhotoUploadService extends Service {
    public static final String EXTRA_TOKEN = "bot_token";
    public static final String EXTRA_URIS = "photo_uris";
    private static final String CHANNEL = "photo_upload_channel";
    private static final int NOTIFICATION_ID = 1928;
    private volatile boolean stopped = false;
    private Thread worker;

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (worker != null && worker.isAlive()) { stopped = true; worker.interrupt(); }
        stopped = false;
        startForeground(NOTIFICATION_ID, notification("در حال آماده‌سازی ارسال عکس‌ها…"));
        String token = intent.getStringExtra(EXTRA_TOKEN);
        ArrayList<Uri> uris = intent.getParcelableArrayListExtra(EXTRA_URIS);
        worker = new Thread(() -> uploadAll(token, uris, startId), "TelegramPhotoUploader");
        worker.start();
        return START_NOT_STICKY;
    }

    private void uploadAll(String token, ArrayList<Uri> uris, int startId) {
        try {
            if (token == null || !token.matches("[0-9]+:[A-Za-z0-9_-]+")) throw new Exception("توکن ربات معتبر به نظر نمی‌رسد.");
            String chatId = findChatId(token);
            if (uris == null || uris.isEmpty()) throw new Exception("عکسی برای ارسال وجود ندارد.");
            int sent = 0;
            for (Uri uri : uris) {
                if (stopped || Thread.currentThread().isInterrupted()) break;
                sent++;
                updateNotification("در حال ارسال عکس " + sent + " از " + uris.size());
                sendPhoto(token, chatId, uri);
            }
            updateNotification(stopped ? "ارسال متوقف شد." : "ارسال تمام شد: " + sent + " عکس");
            Thread.sleep(1800);
        } catch (Exception e) {
            updateNotification("خطا: " + safeMessage(e));
            try { Thread.sleep(3500); } catch (InterruptedException ignored) {}
        } finally { stopForeground(true); stopSelf(startId); }
    }

    private String findChatId(String token) throws Exception {
        JSONObject updates = getJson("https://api.telegram.org/bot" + token + "/getUpdates");
        JSONArray results = updates.optJSONArray("result");
        if (results != null) {
            for (int i = results.length() - 1; i >= 0; i--) {
                JSONObject update = results.getJSONObject(i);
                JSONObject message = update.optJSONObject("message");
                if (message == null) message = update.optJSONObject("edited_message");
                if (message == null) continue;
                JSONObject from = message.optJSONObject("from");
                JSONObject chat = message.optJSONObject("chat");
                if (chat == null) continue;
                String username = from == null ? "" : from.optString("username", "");
                if (username.equalsIgnoreCase("Wahid_2819")) return String.valueOf(chat.getLong("id"));
            }
        }
        throw new Exception("مقصد پیدا نشد. در ربات @Mistrious_1928_bot دکمه Start را بزن و یک پیام مثل Hi بفرست؛ سپس دوباره تلاش کن.");
    }

    private JSONObject getJson(String address) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(15000); c.setRequestMethod("GET");
        try { String body = readAll(c.getInputStream()); JSONObject json = new JSONObject(body); if (!json.optBoolean("ok")) throw new Exception(json.optString("description", "خطای تلگرام")); return json; }
        finally { c.disconnect(); }
    }

    private void sendPhoto(String token, String chatId, Uri uri) throws Exception {
        String boundary = "----MrMistrious" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.telegram.org/bot" + token + "/sendPhoto").openConnection();
        c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setDoOutput(true); c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (DataOutputStream out = new DataOutputStream(c.getOutputStream())) {
            writeField(out, boundary, "chat_id", chatId);
            out.writeBytes("--" + boundary + "\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"photo.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n");
            try (InputStream in = getContentResolver().openInputStream(uri)) { if (in == null) throw new Exception("خواندن عکس ممکن نشد."); byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) != -1) { if (stopped) throw new InterruptedException(); out.write(buffer, 0, n); } }
            out.writeBytes("\r\n--" + boundary + "--\r\n"); out.flush();
        }
        int code = c.getResponseCode();
        InputStream response = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String body = readAll(response); c.disconnect();
        JSONObject json = new JSONObject(body);
        if (!json.optBoolean("ok")) throw new Exception(json.optString("description", "ارسال عکس ناموفق بود."));
    }

    private void writeField(DataOutputStream out, String boundary, String name, String value) throws Exception {
        out.writeBytes("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n");
    }
    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) { String line; while ((line = r.readLine()) != null) b.append(line); }
        return b.toString();
    }
    private String safeMessage(Exception e) { String s = e.getMessage(); return s == null ? "خطای ناشناخته" : s; }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) { NotificationChannel ch = new NotificationChannel(CHANNEL, "ارسال عکس به تلگرام", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(ch); }
    }
    private Notification notification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        if (Build.VERSION.SDK_INT >= 26) return new Notification.Builder(this, CHANNEL).setContentTitle("Mr. Mistrious").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_upload).setContentIntent(pi).setOngoing(true).build();
        return new Notification.Builder(this).setContentTitle("Mr. Mistrious").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_upload).setContentIntent(pi).setOngoing(true).build();
    }
    private void updateNotification(String text) { NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE); nm.notify(NOTIFICATION_ID, notification(text)); }
    @Override public void onDestroy() { stopped = true; if (worker != null) worker.interrupt(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
